//#include "BinaryTree.h"
#include "BinarySearchTree.h"
#include <iostream>
using namespace std;

int main() {

    BinarySearchTree<int> mytree;

    mytree.insert(10);
    mytree.insert(5);
    mytree.insert(15);

    //mytree.draw("BStree",0,true);

    mytree.insert(21);
    mytree.insert(35);
    mytree.insert(42);

    //mytree.draw("BStree", 0, true);

    mytree.insert(11);
    mytree.insert(7);
    mytree.insert(29);

    //mytree.draw("BStree", 0, true);

    //test functions
    if (mytree.find(42))
        cout << "Successfully found 42" << endl;
    else
        cout << "Error: 42 was not found" << endl;
    if (mytree.find(15))
        cout << "Successfully found 15" << endl;
    else
        cout << "Error: 42 was not found" << endl;

    if (mytree.find(101))
        cout << "Error: found 101 in tree" << endl;
    else
        cout << "Successful did not find 101 in tree" << endl;

    //need to test remove!
    mytree.insert(18); // Add in some more members to "stress test" it
    mytree.insert(16);
    mytree.insert(17);
    mytree.insert(20);
    mytree.insert(19);

    mytree.draw("./draw/BStree1", 0, false); // Draw before removing anything

    mytree.remove(42);                       // Remove a leaf node
    mytree.draw("./draw/BStree2", 0, false); // Draw the new tree

    mytree.remove(5);                        // Remove a node with one child
    mytree.draw("./draw/BStree3", 0, false); // Draw the new tree

    mytree.remove(15);                       // Remove a node with 2 subtrees
    mytree.draw("./draw/BStree4", 0, false); // Draw the new tree

    if (!mytree.find(42))                    // Check that each of the elements
        cout << "Successfully removed 42" << endl; // were removed properly
    else
        cout << "42 was not removed." << endl;
    if (!mytree.find(5))
        cout << "Successfully removed 5" << endl;
    else
        cout << "5 was not removed." << endl;
    if (!mytree.find(15))
        cout << "Successfully removed 15" << endl;
    else
        cout << "15 was not removed" << endl;

}
