#include "SLinkedList.h"
#include <iostream>
#include <stdexcept>
#include <string>
using namespace std;

int main() {

    SLinkedList<int> mylist, mylist2;

    if (mylist.empty())
        cout << "list is empty" << endl; // should print

    mylist.addFront(10);
    mylist.addFront(15);
    mylist.addFront(139);
    mylist.addFront(-139);
    cout << mylist.front() << endl;  //should be 15
    mylist2 = mylist;

    mylist.printlist();
    cout << "SIZE: " << mylist.size() << endl;
    cout << "GET LAST: " << mylist.getLast() << endl;
    cout << "MAXIMUM: " << mylist.maximum() << endl;

    mylist.removeFront();
    cout << "LIST 1 FRONT: " << mylist.front() << endl;
    cout << "LIST 2 FRONT: " << mylist2.front() << endl;

}
