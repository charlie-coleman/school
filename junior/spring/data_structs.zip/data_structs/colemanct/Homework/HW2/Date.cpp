#include <iostream>
#include <string>
#include <sstream>

const std::string months[12] = {"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};
class Date {
    private:
        int day, month, year;
    public:
        Date(int d = 1, int m = 1, int y = 2000) {
            day = (d >= 1 && d <= 31) ? d : 1;
            month = (m >= 1 && m <= 12) ? m : 1;
            year = y;
        }

        int getDay() {
            return day;
        }
        int setDay(int d) {
            day = d;
            return day;
        }
        
        int getMonth() {
            return month;
        }
        int setMonth(int m) {
            month = m;
            return month;
        }
        
        int getYear() {
            return year;
        }
        int setYear(int y) {
            year = y;
            return year;
        }

        std::string printableDate1() {
            std::string output = "";
            std::stringstream ss;
            ss << month << '/' << day << '/' << year;
            output = ss.str();

            return output;
        }

        std::string printableDate2() {
            std::string output = "";
            std::stringstream ss;
            ss << day << ' ' << months[month-1] << ' ' << year;
            output = ss.str();

            return output;
        }

        std::string printableDate3() {
            std::string output = "";
            std::stringstream ss;
            ss << months[month-1] << ' ' << day << ", " << year;
            output = ss.str();

            return output;
        }

        std::string trueDate() {
            std::string output = "";
            std::stringstream ss;
            ss << year << '-' << month << '-' << day;            
            output = ss.str();
            
            return output;
        }
};

int main() {
    Date date1;
    Date date2(25, 1, 2018);
    Date date3(2, 6, 1997);

    std::cout << date1.printableDate1() << std::endl;
    std::cout << "This matches expected: " << (date1.printableDate1() == "1/1/2000") << std::endl;
    std::cout << date1.printableDate2() << std::endl;
    std::cout << "This matches expected: " << (date1.printableDate2() == "1 January 2000") << std::endl;
    std::cout << date1.printableDate3() << std::endl;
    std::cout << "This matches expected: " << (date1.printableDate3() == "January 1, 2000") << std::endl << std::endl;

    std::cout << date2.printableDate1() << std::endl;
    std::cout << "This matches expected: " << (date2.printableDate1() == "1/25/2018") << std::endl;
    std::cout << date2.printableDate2() << std::endl;
    std::cout << "This matches expected: " << (date2.printableDate2() == "25 January 2018") << std::endl;
    std::cout << date2.printableDate3() << std::endl;
    std::cout << "This matches expected: " << (date2.printableDate3() == "January 25, 2018") << std::endl << std::endl;

    std::cout << date3.printableDate1() << std::endl;
    std::cout << "This matches expected: " << (date3.printableDate1() == "6/2/1997") << std::endl;
    std::cout << date3.printableDate2() << std::endl;
    std::cout << "This matches expected: " << (date3.printableDate2() == "2 June 1997") << std::endl;
    std::cout << date3.printableDate3() << std::endl;
    std::cout << "This matches expected: " << (date3.printableDate3() == "June 2, 1997") << std::endl;

    return 0;
}
