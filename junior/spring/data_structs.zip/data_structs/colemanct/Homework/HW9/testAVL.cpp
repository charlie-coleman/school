//#include "BinaryTree.h"
#include "AVLTree.h"
#include <iostream>
using namespace std;

int main() {

    AVLTree<int> mytree;

    mytree.insert(10);
    mytree.insert(5);
    mytree.insert(15);
    cout << "past insert" << endl;

    mytree.draw("AVLtree",0,false);

    //triggers no rotation
    mytree.insert(21);
    mytree.draw("AVLtree",0,false);

    //triggers rotation in right side
    mytree.insert(35);
    mytree.draw("AVLtree",0,false);

    //triggers rotation at root
    mytree.insert(42);
    mytree.draw("AVLtree", 0, false);

    //triggers no rotation on either side
    mytree.insert(20);
    mytree.insert(44);
    mytree.draw("AVLtree",0,false);


    //triggers rotation at 15
    mytree.insert(18);
    mytree.draw("AVLtree",0,false);

    //triggers rotation at 10
    mytree.insert(17);
    mytree.draw("AVLtree",0,false);

    //trigger a rotation at 10
    mytree.insert(3);
    mytree.draw("AVLtree",0,false);

    //trigger rotation at root - 18 new root
    mytree.insert(16);
    mytree.draw("AVLtree",0,false);

    //test functions
    if (mytree.find(10))
    cout << "Successfully found 10" << endl;
    else
    cout << "Error: 11 was not found" << endl;
    if (mytree.find(35))
    cout << "Successfully found 35" << endl;
    else
    cout << "Error: 35 was not found" << endl;

    if (mytree.find(101))
    cout << "Error: found 101 in tree" << endl;
    else
    cout << "Successful did not find 101 in tree" << endl;

    mytree.draw("./draw/AVLtree0", 0, false);

    // Remove 20, causing an unbalanced tree. For left subtree of root,
    //              42
    //      21             44
    //          35
    mytree.remove(20);
    mytree.draw("./draw/AVLtree1", 0, false);

    // Remove 44, causing unbalanced tree. For left subtree of _root
    //              35
    //      21              42
    mytree.remove(44);
    mytree.draw("./draw/AVLtree2", 0, false);

    //Remove 10. Shouldn't cause unbalanced tree
    mytree.remove(10);
    mytree.draw("./draw/AVLtree3", 0, false);

    // Remove 5 and 35. Overall tree structure after
    //                      18
    //          15                      42
    //      3       17              21
    //           16
    mytree.remove(5);
    mytree.remove(35);
    mytree.draw("./draw/AVLtree4", 0, false);

    if(mytree.find(20))
        cout << "Error: found 20" << endl;
    else
        cout << "Successfully removed 20" << endl;
    if(mytree.find(44))
        cout << "Error: found 44" << endl;
    else
        cout << "Successfully removed 44" << endl;
    if(mytree.find(10))
        cout << "Error: found 10" << endl;
    else
        cout << "Successfully removed 10" << endl;
    if(mytree.find(5))
        cout << "Error: found 5" << endl;
    else
        cout << "Successfully removed 5" << endl;
    if(mytree.find(35))
        cout << "Error: found 35" << endl;
    else
        cout << "Successfully removed 35" << endl;

}
