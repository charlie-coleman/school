#include <iostream>
#include "List.h"


void printList(List<int>& l) {
    List<int>::iterator it;
    for (it = l.begin(); it != l.end(); it++)
        cout << *it << " ";
    cout << endl;
}

int main() {

    List<int> mylist;
    List<int>::iterator it;

    mylist.push_front(5);
    mylist.push_front(11);
    mylist.push_front(21);

    printList(mylist);

    it = mylist.begin();
    *it = *it + 12;

    it++;
    mylist.insert(it,10);

    printList(mylist);

    mylist.pop_back();
    mylist.pop_front();

    printList(mylist);

    //test copy constructor
    List<int> otherlist(mylist);
    otherlist.print_list();
    mylist.push_front(-3);
    mylist.print_list();

    //test operator=
    mylist = otherlist;
    mylist.print_list();

    cout << endl << endl << endl;

    List<int> hwList;
    hwList.push_front(0);
    hwList.push_front(1);
    hwList.push_front(2);
    hwList.push_front(3);
    hwList.push_front(4);
    hwList.push_front(5);
    hwList.push_front(0);

    cout << "DEFAULT LIST" << endl;
    for(it = hwList.begin(); it != hwList.end(); it++)
        cout << *it << " ";
    cout << endl << endl;

    cout << "RETURN 5TH ELEMENT" << endl;
    // Test [] operator, should output 1
    cout << hwList[5] << endl << endl;

    // Test replace function, should print 100 5 4 3 2 1 100
    cout << "REPLACE 0 WITH 100" << endl;
    hwList.replace(0, 100);
    for(it=hwList.begin(); it != hwList.end(); it++)
        cout << *it << " ";
    cout << endl << endl;

    // Test reverse function, should print 100 1 2 3 4 5 100
    cout << "REVERSE THE LIST" << endl;
    hwList.reverse();
    for(it=hwList.begin(); it!=hwList.end(); it++)
        cout << *it << " ";
    cout << endl << endl;

    cout << "SORT THESE LIST" << endl;
    cout << "INITIAL STATE: ";
    printList(hwList);
    cout << "SORTED  STATE: ";
    hwList.bubbleSort();
    printList(hwList);
    cout << endl;


    List<int> sortList;
    sortList.push_front(3);
    sortList.push_front(2);
    sortList.push_front(1);
    sortList.push_front(4);
    sortList.push_front(5);
    sortList.push_front(0);
    sortList.push_front(1);

    cout << "INITIAL STATE: ";
    printList(sortList);
    cout << "SORTED  STATE: ";
    sortList.bubbleSort();
    printList(sortList);



}
