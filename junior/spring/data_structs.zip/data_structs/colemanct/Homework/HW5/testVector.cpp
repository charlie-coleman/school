#include <iostream>
#include "Vector.h"
using namespace std;

void printVec(Vector<int>& v) {
    for(int i = 0; i < v.size(); i++) {
        cout << v[i] << " ";
    }
    cout << endl;
}

int main() {

    //test constructor
    Vector<int> intvec(2);
    Vector<char> charvec;

    //should test push_back, insert, and resizing in insert
    for (int i = 0; i < 15; i+=2)
        intvec.push_back(i);

    //test operator[] and size()
    printVec(intvec);

    //test erase
    intvec.erase(3);

    //now 6 at position 3 should be gone
    printVec(intvec);

    Vector<int> mycopy(intvec);
    printVec(mycopy);

    mycopy.push_back(56);
    mycopy.insert(0,68);
    printVec(intvec);

    printVec(mycopy);

    intvec = mycopy;
    printVec(intvec);

    cout << endl << endl << "TESTING REMOVE & REPLACE" << endl;
    intvec.insert(7, 4); // Add a second instance of 4 in the Vector
    intvec.push_back(4); // Add another
    printVec(intvec);
    intvec.remove(4); // Remove the FIRST instance of 4
    printVec(intvec);
    intvec.replace(4, 12345); // Replace ALL instances of 4 with 12345
    printVec(intvec);

    cout << endl << endl << "TESTING REVERSE" << endl;
    intvec.reverse(); // Reverse the list
    printVec(intvec);
    intvec.push_back(1); // Add one to end, make sure this works for odd # of elems
    intvec.reverse();
    printVec(intvec);

    cout << endl << endl << "TESTING RESIZE" << endl;
    intvec.resize(15, 31415); // Increase size to 15, fill with 31415
    printVec(intvec);
    intvec.resize(8, 0); // Decrease the size to 8, last elem should be 12345
    printVec(intvec);

    cout << endl << endl << "TESTING ERASE" << endl;
    int presize = intvec.size();
    for (int i = 0; i < presize; i++) { // Remove every object in intvec one by one
        for (int i = 0; i < intvec.size(); i++) { // print the size and capacity each time
            cout << intvec[i] << " ";
        }
        cout << " <---- SIZE: " << intvec.size() << " CAP: " << intvec.capacity() << endl;
        intvec.erase(0);
    }
    cout << " <---- SIZE: " << intvec.size() << " CAP: " << intvec.capacity() << endl;
    intvec.insert(0,1);
    intvec.insert(0,1);
    intvec.insert(0,1);
    intvec.insert(0,1);
    intvec.insert(0,1);

    cout << intvec.count(1) << endl;

    charvec.insert(0,'a');
    cout << endl << endl <<charvec[0] << endl;
}
