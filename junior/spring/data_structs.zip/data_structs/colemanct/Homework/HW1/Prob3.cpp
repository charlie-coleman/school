#include <iostream>
#include <string>

int main() {
	char input;
	std::cout << "Enter a letter: ";
	std::cin >> input;

	std::cout << "Display the operation of pre and post increment and decrement :" << std::endl;
	std::cout << "--------------------------------------------------------------------" << std::endl;
	std::cout << "The letter is: " << input << std::endl;
	std::cout << "If I use post increment (letter++) the number is now: " << input++ << std::endl;
	std::cout << "  And now my letter is: " << input << std::endl;
	std::cout << "Now if I pre-increment (++letter) in my cout I get: " << ++input << std::endl;
	std::cout << "  And now my letter is: " << input << std::endl;
	std::cout << "If I use post decrement (letter--) the number is now: " << input-- << std::endl;
	std::cout << "  And now my letter is: " << input << std::endl;
	std::cout << "Now if I pre-decrement (--letter) in my cout I get: " << --input << std::endl;
	std::cout << "  And now my letter is: " << input << std::endl;

	return 0;
}