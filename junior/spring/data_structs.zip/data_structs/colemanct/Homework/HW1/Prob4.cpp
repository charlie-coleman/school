#include <iostream>
#include <string>

bool isPerfect(int number) {
	int sum = 0;
	for (int i = 1; i < number; i++) {
		if (number % i == 0) {
			sum += i;
		}
	}
	return (sum == number);
}

int main() {
	for (int i = 1; i < 9999; i++) {
		if (isPerfect(i)) {
			std::cout << i << std::endl;
		}
	}
}