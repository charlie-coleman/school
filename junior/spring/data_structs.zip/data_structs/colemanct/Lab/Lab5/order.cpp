#include <iostream>
#include <vector>
#include <string>

int main() {
    int length = -1;
    int setNum = 1;
    while (length != 0) {
        std::cin >> length;
        if (length != 0)
            std::cout << "SET " << setNum << std::endl;
        std::vector<std::string> names;
        std::string tempInput;
        for (int i = 0; i < length; i++) {
            std::cin >> tempInput;
            names.push_back(tempInput);
        }
        for (int i = 0; i < length; i=i+2)
            std::cout << names[i] << std::endl;
        for (int i = length-(length%2)-1; i > 0; i=i-2)
            std::cout << names[i] << std::endl;
        setNum++;
    }
}
