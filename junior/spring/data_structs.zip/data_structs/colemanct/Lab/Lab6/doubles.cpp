#include <iostream>
#include <vector>
#include <string>

int countDoubles(std::vector<int> v, int size) {
    int doubles = 0;
    for (int i = 0; i < size; i++) {
        for (int j = i+1; j < size; j++) {
            if ((v[i] == 2*v[j]) || (2*v[i] == v[j]))
                doubles++;
        }
    }
    return doubles;
}

int main() {
    int input = 0;
    int size = 0;
    std::vector<int> numbers;
    std::cout << "Enter lists of numbers, each list ending in 0. To exit, enter -1" << std::endl;
    std::cin >> input;
    while (input != -1) {
        numbers.clear();
        size = 0;
        while (input != 0) {
            numbers.push_back(input);
            size ++;
            std::cin >> input;
        }
        std::cin >> input;
        std::cout << countDoubles(numbers, size) << std::endl;
    }
    return 0;
}
