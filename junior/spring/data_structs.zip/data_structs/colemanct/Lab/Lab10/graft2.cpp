#include <iostream>
#include <string>

int originalDepth(std::string::iterator& i, int depth) {
    int tempDepth = 0;
    int maxDepth = depth;
    std::string::iterator nexti = i + 1;
    std::cout << *i << std::endl;
    if(*i == 'd' && *nexti == 'u') {
        tempDepth = 0;
        i = i + 2;
    }
    else {
        if(*i == 'd')
            tempDepth =  1 + originalDepth(++i, maxDepth);
        else
            tempDepth = -1 + originalDepth(++i, maxDepth);
    }
    if(*i)
        tempDepth = originalDepth(i, maxDepth);
    else
        return maxDepth;
    if(maxDepth < tempDepth)
        maxDepth = tempDepth;
    return maxDepth;
}

int modifiedDepth(std::string::iterator& i) {

    return 0;
}

int main() {
    std::string input;
    int count = 1;
    std::cin >> input;
    while (input != "#") {
        input = "d" + input + "u";
        std::string::iterator it = input.begin();
        std::cout << "Tree " << count << ": " << originalDepth(it, 0) << " => ";
        it = input.begin();
        std::cout << modifiedDepth(it) << std::endl;
        std::cin >> input;
        count ++;
    }

}
