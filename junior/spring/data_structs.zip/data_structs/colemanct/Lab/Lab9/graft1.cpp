#include <iostream>
#include <string>

int depth(std::string::iterator& it, std::string::iterator& e) {
    int max = 0;
    int curr = 0;
    for (it; it != e; it++) {
        if(*it == 'd')
            curr ++;
        else
            curr --;
        if (max < curr)
            max = curr;
    }
    return max;
}

int main() {
    int count = 1;
    std::string input;
    std::cout << "Enter navigation paths, enter # to quit: " << std::endl;
    std::cin >> input;
    while(input != "#") {
        std::string::iterator it = input.begin();
        std::string::iterator endIt = input.end();
        std::cout << "Tree " << count << ": " << depth(it, endIt) << std::endl;
        std::cin >> input;
        count ++;
    }
    return 0;
}
