#include <iostream>
#include <string>

int calculatePercentage(int iW, int iH, int pW, int pH) {
    int calcPercent, p1, p2;
    int iSmall, pSmall;
    int iLarge, pLarge;
    
    pLarge = (pW < pH) ? pH : pW;
    pSmall = (pW < pH) ? pW : pH;
    
    // std::cout << pLarge << std::endl << pSmall << std::endl;
    
    iLarge = (iW < iH) ? iH : iW;
    iSmall = (iW < iH) ? iW : iH;
    
    // std::cout << iLarge << std::endl << iSmall << std::endl;
    
    p1 = (100*pLarge) / iLarge;
    p2 = (100*pSmall) / iSmall;
    
    calcPercent = (p1 < p2) ? p1 : p2;
    
    calcPercent = (calcPercent > 100) ? 100 : calcPercent;
    
    return calcPercent;
}

int main() {
    float calcPercent;
    int input[4];
    do {
        std::cout << "Please input the size of the image and paper, seperated by whitespace." << std::endl;
        std::cout << "(enter all 0s to quit)" << std::endl;
        std::cin >> input[0] >> input[1] >> input[2] >> input[3];
    	if(!(input[0] == 0 && input[1] == 0 && input[2] == 0 && input[3] == 0)) {
            calcPercent = calculatePercentage(input[0], input[1], input[2], input[3]);
            std::cout << "The maximum size is: " << calcPercent << '%' << std::endl << std::endl << std::endl;
        }
    } while(!(input[0] == 0 && input[1] == 0 && input[2] == 0 && input[3] == 0)); 
    return 0;
}
