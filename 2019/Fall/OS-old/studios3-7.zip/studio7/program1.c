#include <stdio.h>
#include <unistd.h>

int main(int argc, char* argv[]) {
	printf("This is an output from Program 1.\n");

	return 0;
}
