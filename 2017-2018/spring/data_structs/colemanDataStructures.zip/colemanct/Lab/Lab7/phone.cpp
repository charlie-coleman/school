#include <iostream>
#include <string>
#include <vector>

bool isValid(std::vector<std::string> v) {
    bool valid = true;
    for (int i = 0; i < v.size()-1; i++) {
        for (int j = i+1; j < v.size(); j++) {
            if (v[i].size() > v[j].size()) {
                if (v[i].substr(0, v[j].size()) == v[j]) {
                    valid = false;
                    break;
                }
            }
            else {
                if (v[j].substr(0, v[i].size()) == v[i]) {
                    valid = false;
                    break;
                }
            }
        }
    }

    return valid;
}

int main() {
    int trials, phoneNums;
    std::cin >> trials;
    for (int i = 0; i < trials; i ++)  {
        std::cin >> phoneNums;
        std::vector<std::string> numbers;
        for (int j = 0; j < phoneNums; j++) {
            std::string temp;
            std::cin >> temp;
            numbers.push_back(temp);
        }
        std::string output = (isValid(numbers)) ? "YES" : "NO";
        std::cout << output << std::endl;
    }
}
