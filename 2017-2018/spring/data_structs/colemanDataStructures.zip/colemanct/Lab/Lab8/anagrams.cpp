#include <iostream>
#include <stack>
#include <string>

void solve(std::string goal,
           std::string I,
           std::string S,      
           std::string O,
           std::string moves) {
    //std::cout << "solve(" << goal << ',' << I << ',' << S << ',' << O << ',' << moves << ");" << std::endl;
    if (goal == O) // If the goal matches the output, print moves
        std::cout << moves << std::endl;
    if(S.size() > 0) { // If we have any elements in S
        std::string Stemp,Otemp,movesTemp; // Localize variables
        Otemp = O;
        Stemp = S;
        movesTemp = moves;
        
        Otemp.push_back(S.back()); // Moves last elem to output
        Stemp.pop_back(); // Remove from S
        movesTemp.push_back('-'); // Add a - to moves
        solve(goal, I, Stemp, Otemp, movesTemp); // Recurse
    }
    if (I.size() > 0) { // If we have any elements in I
        std::string Itemp,Stemp,movesTemp; // Localize
        Itemp = I;
        Stemp = S;
        movesTemp = moves;
        
        Stemp.push_back(Itemp.front()); // move front of I to S
        Itemp.erase(0,1); // Remove from I
        movesTemp.push_back('+'); // Add + to moves
        solve(goal, Itemp, Stemp, O, movesTemp); // Recurse
    }
    else if (S.size() == 0 && I.size() == 0) {
        return;
    }
}


int main() {
    int num;
    std::cin >> num; // get the number of sets
    for(int i = 0; i < num; i++) { // Run 'num' times
        std::string input, goal;
        std::cin >> input >> goal; // take user input
        std::cout << "Output for " << input << " " << goal << std::endl; // Print the required stuff
        std::cout << '[' << std::endl;
        solve(goal, input, "", "" , ""); // Solve it
        std::cout << ']' << std::endl;
    }
    return 0;
}
