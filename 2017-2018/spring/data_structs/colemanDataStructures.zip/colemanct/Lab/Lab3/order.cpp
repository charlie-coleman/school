#include <iostream>
#include <stack>
#include <string>
#include <sstream>

int main() {
	std::stack <std::string> names; // Stack of names
	std::stack <std::string> otherSet; // other stack for transferring back and forth
	std::string tempString = ""; // holds a string that will be pushed to the stack
	std::string numNamesString; // holds the number of names as a string
	int numNames; // holds the number of names as an int
	int set = 0; // the number of the current set

	std::cout << "Enter the number of names followed by all names in increasing length order." << std::endl; 
	std::cout << "Enter 0 to stop." << std::endl;

	do {
		tempString = "";
		std::cin >> tempString;
		names.push(tempString);
	} while (tempString != "0"); // Continue to recieve input until a "0" is entered

	names.pop(); // remove the final zero
	while(!names.empty()) { // switch the stacks, this flips the order so that the
		otherSet.push(names.top()); // number of names is at the start
		names.pop();
	}

	while(!otherSet.empty()) {
		set ++; // increment the set counter

		names = std::stack<std::string>(); // clear the "names" stack

		numNamesString = otherSet.top(); // get the first element in the stack of names
		otherSet.pop();			 // should be the number of names in the set

		std::istringstream (numNamesString) >> numNames; // convert the string to an int
		std::cout << "SET " << set << std::endl; 	 // output "SET #"

		for(int i = 0; i < numNames; i++) {
			if(i % 2 == 0) // For the even indices of the stack, print
				std::cout << otherSet.top() << std::endl;
			else	       // For all the other ones, add to name stack for now
				names.push(otherSet.top());
			otherSet.pop();
		}

		int namesLeft = names.size();
		for(int i = 0; i < namesLeft; i++) { // Print the rest of the names out
			std::cout << names.top() << std::endl; // They'll be in backwards order now
			names.pop();
		}
	}
	return 0;
}
