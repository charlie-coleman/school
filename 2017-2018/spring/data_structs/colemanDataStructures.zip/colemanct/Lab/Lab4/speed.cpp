#include <iostream>
#include <string>
#include <string>

int milesDriven(int length, int speedArr[], int timeArr[]) {
    int output = 0;
    for (int i = 0; i < length; i++) {
        int timeAtSpeed, speed;
        if (i == 0)
            timeAtSpeed = timeArr[i];
        else
            timeAtSpeed = timeArr[i] - timeArr[i-1];
        speed = speedArr[i];
        output += speed * timeAtSpeed;
    }
    return output;
}

int main() {
    int length;
    while (true) {
        std::cin >> length;
        while(std::cin.fail()) {
            std::cout << "Length must be an integer!" << std::endl;
            std::cin.clear();
            std::cin.ignore(256,'\n');
            std::cin >> length;
        }
        if (length == -1)
            break;
        int speedArr[length], timeArr[length];
        for(int i = 0; i < length; i++) {
            std::cin >> speedArr[i];
            while(std::cin.fail()) {
                std::cout << "Speed must be an integer!" << std::endl;
                std::cin.clear();
                std::cin.ignore(256,'\n');
                std::cin >> speedArr[i];
            }

            std::cin >> timeArr[i];
            while(std::cin.fail()) {
                std::cout << "Time must be an integer!" << std::endl;
                std::cin.clear();
                std::cin.ignore(256,'\n');
                std::cin >> timeArr[i];
            }
        }
        std::cout << milesDriven(length, speedArr, timeArr) << " miles" << std::endl;
    }

    return 0;
}
