#include "BinaryTree.h"
using namespace std;

template <typename ItemType>
class BinarySearchTree : public BinaryTree<ItemType> {

public:

    /**
    * Function to insert an element into the BST
    * Input Parameter: the element to insert
    * Return value: the position of the new node
    */
    typename BinaryTree<ItemType>::Iterator insert(const ItemType& element) {

        //check if tree is empty and put new element as root, if so
        if (BinaryTree<ItemType>::empty()) {
            BinaryTree<ItemType>::createRoot(element);
            return BinaryTree<ItemType>::root();
        }
        else {
            //Find position where the new value should go in current tree
            typename BinaryTree<ItemType>::Iterator position = BinaryTree<ItemType>::root();
            while (true) {
                if (*position < element) {
                    if (position.hasRightChild())
                    position = position.right();
                    else
                    break;
                }
                else {
                    if (position.hasLeftChild())
                    position = position.left();
                    else
                    break;
                }
            }

            //Insert the new node - just below position
            if (element <= *position) {
                BinaryTree<ItemType>::insertAsLeftChild(element, position);
                position = position.left();
            }
            else {
                BinaryTree<ItemType>::insertAsRightChild(element, position);
                position = position.right();
            }
            return position;

        }

    } //end of insert

    /**
    * Function to find if an element is in the tree
    * Input Parameter: the element to search for
    * Return value: a boolean which is true if the element is in the tree
    */
    bool find(const ItemType& value) {

        //make an iterator for root
        typename BinaryTree<ItemType>::Iterator position = BinaryTree<ItemType>::root();

        while (!position.isNULL()) {
            if (*position == value) {
                return true;
            }
            else {
                if (*position > value)
                position = position.left();
                else
                position = position.right();
            }
        } //ends while

        return false;
    } //end of find

    /**
    * Function to remove an element from the tree
    */
    typename BinaryTree<ItemType>::Iterator remove(const ItemType& element) {
        typename BinaryTree<ItemType>::Iterator position = BinaryTree<ItemType>::root();
        while(!position.isNULL()) {
            if (*position == element) {
                break;
            }
            else {
                if (*position > element)
                position = position.left();
                else
                position = position.right();
            }
        }
        if(!position.isNULL()) {
            // First case: the node is a leaf or it has one element on it's left
            // Easy! just delete and move left child up!
            if ((!position.hasRightChild() && !position.hasLeftChild())
            || (!position.hasRightChild() && position.hasLeftChild()))
                BinaryTree<ItemType>::deleteAndMoveLeftChildUp(position);
            // If the only child is on the right, it's still easy. Just move up
            else if(position.hasRightChild() && !position.hasLeftChild())
                BinaryTree<ItemType>::deleteAndMoveRightChildUp(position);
            // Third case and the trickiest. What if you have 2 children?
            // Move right then move as far left as possible to find the next
            // smallest element. Change the value of the item being removed to
            // that value and delete the original instance of that node.
            // Because the node may have a right child, we move that one up
            else if(position.hasRightChild() && position.hasLeftChild()) {
                typename BinaryTree<ItemType>::Iterator positionTrav = position.right(); // move right 1
                while(positionTrav.hasLeftChild() && !positionTrav.isNULL()) {
                    positionTrav = positionTrav.left(); // move as far left as possible
                }
                *position = *positionTrav; // Change the value of the elem being replaced
                BinaryTree<ItemType>::deleteAndMoveRightChildUp(positionTrav); // delete the node
            }
        }
        return position;
    } //end of remove


}; // end BinarySearchTree.h
