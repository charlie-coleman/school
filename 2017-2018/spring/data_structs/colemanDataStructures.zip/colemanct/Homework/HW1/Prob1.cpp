// HW1.cpp : Defines the entry point for the console application.
//
#include<string>
#include<iostream>


int main()
{
	std::string beverages[] = { "Water", "Coffee", "Milk", "Tea", "Lemonade" };
	int choice;
	std::cout << "Choose your preferred beverage:" << std::endl;
	for (int i = 0; i < 5; i++) {
		std::cout << (i+1) << ". " << beverages[i] << std::endl;
	}
	do {
		std::cin >> choice;
	} while (choice > 5 || choice < 1);
	std::cout << "You chose: " << beverages[choice-1] << std::endl;

	return 0;
}

