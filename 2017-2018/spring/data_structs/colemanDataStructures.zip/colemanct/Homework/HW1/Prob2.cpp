#include <iostream>
#include <string>

void printSquare(int size, char fillChar) {
	for (int i = 0; i < size; i++) {
		for (int j = 0; j < size; j++) {
			std::cout << fillChar;
		}
		std::cout << std::endl;
	}
}

int main() {

	printSquare(5, '@');

	printSquare(10, '!');

	return 0;
}