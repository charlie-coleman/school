#include "BitStreams.h"
#include "BinaryTree.h"
#include "VariousExceptions.h"
#include <iostream>
#include <string>

void createTree(BinaryTree<int>& btree, BinaryTree<int>::Iterator& it, InBitStream& ibs) {
    // Root Left Right
    int bit = ibs.read(); // get the next bit
    int character; // holder for the 9 bit character
    if(bit == 0) { // if the node is an internal node
        if(!it.hasLeftChild()) {
            btree.insertAsLeftChild(it, 0); // create a dummy node (internal)
            it = it.left(); // move to it
        }
        else if(!it.hasRightChild()) {
            btree.insertAsRightChild(it, 0); // create a dummy node (internal)
            it = it.right(); // move to that node
        }
        else { // This should never happen if the header is correct
            std::cout << "Something has gone horrible wrong!" << std::endl;
        }
        createTree(btree, it, ibs); // continue creating the tree.
    }
    else if(bit == 1) { // If the node is an external node
        character = ibs.read(9); // get the next 9 bits for the character
        if(!it.hasLeftChild()) {
            btree.insertAsLeftChild(it, character); // Stick the character at the empty leaf
            createTree(btree, it, ibs); // and continue creating the tree
        }
        else if(!it.hasRightChild()) {
            btree.insertAsRightChild(it, character); // Stick the character at the empty leaf
            while(it.hasRightChild() && it.hasLeftChild() && !it.isRoot())
            // Move up the tree until you reach a point with only 1 child
            // or you get to the root
                it = it.up();
            if(!(it.isRoot() && it.hasRightChild() && it.hasLeftChild()))
            // If we've reached the root and it has 2 children, the tree must be complete!
            // Else, continue creating
                createTree(btree, it, ibs);
            //else // UNCOMMENT TO GET THE TREE FOR A FILE
            //    btree.draw("btree", 0, false); //IT LOOKS PRETTY COOL
        }
    }
}

void decodeMessage(BinaryTree<int>& btree, InBitStream& ibs, OutBitStream& obs) {
    BinaryTree<int>::Iterator it = btree.root(); // create an iterator at the root
    bool endofmessage = false; // to trigger when we hit end of message.
    while(!endofmessage && !ibs.eof()) { // while not at end of message
                                        // and not at end of file just in case.
        while(!it.isLeaf()) { // While we are not at a leaf
            int bit = ibs.read(1); // get the next bit
            if(bit == 0) // if 0, move left
                it = it.left();
            else //         if 1, move right
                it = it.right();
        }
        int character = (*it); // get the value at the leaf
        if(character == 0b0000000100000000) { // if it is the end of message, we are done
            endofmessage = true;
            break;
        }
        else { // if not, write the character to the file.
            obs.write(character, 8);
            it = btree.root(); // Go back to the root.
        }
    }
}

int main() {
    InBitStream ibs; // Create all the streams we need
    OutBitStream obs;
    BinaryTree<int> btree; // create a binary tree for the "key"
    btree.createRoot(0); // add a dummy root
    BinaryTree<int>::Iterator it = btree.root(); // set an iterator to the root
    std::string inputName, outputName; // String to hold file names
    std::cout << "Enter the compressed file to be decoded: "; // Get filenames
    std::cin >> inputName;
    std::cout << "Enter the desired output file path: ";
    std::cin >> outputName;
    bool opened = ibs.open(inputName); // Try to open compressed file
    if(opened) { // if it is successfull
        ibs.read();
        createTree(btree, it, ibs);
        opened = obs.open(outputName); // Try to open the output file
        if (opened) { // If it is successful
            decodeMessage(btree, ibs, obs);
            std::cout << "Success" << std::endl;
            obs.close(); // Always close your files!
        }
        else { // Just in case file open fails
            std::cout << "Failed to open output file." << std::endl;
        }
        ibs.close(); // Always close your files!
    }
    else { // Just in case file open fails
        std::cout << "Failed to open input file." << std::endl;
    }
    return 0;
}
