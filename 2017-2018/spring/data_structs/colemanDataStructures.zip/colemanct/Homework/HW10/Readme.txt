The project works as intended as far as I can tell. Managed to decode Moby Dick, which is cool.



Getting Up and Running:
1. make
2. ./decode
3. Enter the path to the input file
4. Enter the path to the output file
5. Enjoy


The extra credit was not attempted
