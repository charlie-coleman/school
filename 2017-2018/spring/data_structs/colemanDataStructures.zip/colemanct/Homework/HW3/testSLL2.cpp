#include <iostream>
#include "SLinkedList.h"

void printList(SLinkedList<int> l) {
	while (!l.empty()) {
		std::cout << l.front() << std::endl;
		l.removeFront();
	}
}

int main() {
	SLinkedList<int> list;
	list.addFront(1);
	list.addFront(2);
	list.addFront(3);
	list.addFront(4);
	list.addFront(5);
	list.addFront(6);
	list.addFront(7);
	printList(list);
	list.skip();
	std::cout << std::endl << "AFTER SKIP" << std::endl;
	printList(list);
}
